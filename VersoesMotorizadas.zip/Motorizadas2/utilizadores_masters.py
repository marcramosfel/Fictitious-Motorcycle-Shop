import json
import re
import requests
import GLOBAL_VARIABLES

def check_login(user, psw):
    print(user,psw)
    response = requests.post(GLOBAL_VARIABLES.WEB_SERVICE_URI + 'checking_account', json={
        "email": user,
        "password": psw})
    print(response.text)
    return json.loads(response.text)

def coloca_utilizador(nome, psw, nif, email, is_master, telefone):
    valid = re.search(r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9]+\.[a-zA-Z\.a-zA-Z]{1,3}$', email)
    if valid:
        response = requests.post(GLOBAL_VARIABLES.WEB_SERVICE_URI + 'register_account', json={
            "email": email,
            "password": psw,
            "nome": nome,
            "nif": nif,
            "is_master": is_master,
            "telefone": telefone})
        response = json.loads(response.text)
        if response["message"] == "Exception('error_nif_exists')":
            return 'Ja existe um nif associado!'
        elif response["message"] == "Exception('error_email_exists')":
            return 'Ja existe um email associado!'
        elif response["message"] == "success":
            return 'O utilizador master foi criado!!'
        elif response["message"] == """IntegrityError(1062, "Duplicate entry \'2147483647\' for key \'nif_UNIQUE\'")""":
            return 'Ja existe um nif associado!'
    else:
        return 'O email não é válido!!'

    # def registar(self, nome,telefone,nif,email, password, is_master):
    #     json_post = {"nome": nome,"telefone": telefone, "nif":nif,'email': email, "password": password, "is_master": is_master}
    #     response = requests.post(self.uri+'register_account', json=json_post)

#print(Utilizador().check_login('marcos@exemplo.com',"123"))
