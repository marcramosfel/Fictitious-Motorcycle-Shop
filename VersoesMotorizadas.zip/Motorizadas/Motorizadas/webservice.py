from flask import Flask, jsonify, request
from flask_mysqldb import MySQL
from config import config

NOME_BASE_DADOS = 'motorizadas'

app = Flask(__name__)
conexion = MySQL(app)


#/images/
#Motorizadas
@app.route('/motorizadas', methods=['GET'])
def listar_motorizadas():
    try:
        cursor = conexion.connection.cursor()
        sql = "SELECT * FROM "+NOME_BASE_DADOS+".motorizada"
        cursor.execute(sql)
        result = cursor.fetchall()
        return jsonify(result)
    except Exception as err:
        return jsonify({"message": "Something went bad!", 'error' : err.__repr__()})


#Clientes
@app.route('/cliente')
def listar_cliente():
    try:
        cursor = conexion.connection.cursor()
        sql = "SELECT * FROM "+NOME_BASE_DADOS+".clientes"
        cursor.execute(sql)
        resultado = cursor.fetchall()


        clientes = []
        for file in resultado:
            cliente = {'idcliente': file[0],
                       'nome': file[1],
                       'telefone': file[2],
                       'nif': file[3],
                       'email': file[4]}
            clientes.append(cliente)
        #print(cliente)
        return jsonify({"cliente": clientes, "message":"Everything went well!"})
    except Exception as ex:
        return jsonify({"message" : "Something went bad!"})

@app.route('/cliente/<idcliente>', methods=['GET'])
def ler_cliente_especifico(idcliente):
    try:
        idcliente = str(idcliente)
        cursor = conexion.connection.cursor()
        sql = f"""SELECT * FROM {NOME_BASE_DADOS}.clientes WHERE idcliente = {idcliente} """
        cursor.execute(sql)
        resultado = cursor.fetchone()
        if resultado != None:
            cliente = {'idcliente': resultado[0],
                       'nome': resultado[1],
                       'telefone': resultado[2],
                       'nif': resultado[3],
                       'email': resultado[4]}
            return jsonify({"cliente": cliente, "message": "Everything went well!"})
        else:
            return jsonify({"message":"cliente nao encontrado"})
    except Exception as ex:
        return jsonify({"message":"Something went bad!"})

@app.route('/cliente', methods=['POST'])
def inserir_cliente():
    try:
        print(request.json['nome'],request.json['telefone'], request.json['nif'], request.json['email'] )
        cursor = conexion.connection.cursor()
        sql = f"""INSERT INTO {NOME_BASE_DADOS}.clientes (idcliente, nome, telefone, nif, email)  
                           VALUES (
                           DEFAULT,
                           '{request.json['nome']}',
                           {request.json['telefone']},
                           {request.json['nif']},
                           '{request.json['email']}') """
        print(sql)
        cursor.execute(sql)
        print(sql)
        conexion.connection.commit()  # insere na base de dados

        return jsonify({"message": "cliente Criado!"})

    except Exception as ex:
        return jsonify({"message":"Something went bad!"})

def pagina_nao_encontrada(error):
    return "<h1> A Página não foi encontrada!!!... </h1>", 404

if __name__ == "__main__":
    app.config.from_object(config['development'])
    app.register_error_handler(404, pagina_nao_encontrada)
    app.run()

