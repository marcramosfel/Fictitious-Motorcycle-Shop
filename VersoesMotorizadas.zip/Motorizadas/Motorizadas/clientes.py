import requests

from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen
from kivy.uix.textinput import TextInput

class Cliente(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.label_email1 = Label(text='Email')
        self.label_nif1 = Label(text='NIF')
        self.label_telefone1 = Label(text='Telefone')
        self.label_nome1 = Label(text='Nome')
        self.label_id1 = Label(text='ID')

        self.uri = 'http://127.0.0.1:5000/cliente'

    def ver_todos_clientes(self):
        response = requests.get(self.uri)
        resultado = response.json()['cliente']
        print(resultado)

        if self.ids.grid_informacao.cols == 0:
            self.ids.grid_informacao.cols = len(resultado[0])
            self.ids.grid_informacao.size_hint = (1, 1)
            for widget in (self.label_id1, self.label_nome1, self.label_telefone1, self.label_nif1, self.label_email1):
                self.ids.grid_informacao.add_widget(widget)

            for i in range(len(resultado)):
                self.botao_id = Button()
                self.botao_id.bind(on_release=self.mostra)
                self.label_nome = Label()
                self.label_telefone = Label()
                self.label_nif = Label()
                self.label_email = Label()
                self.botao_id.text = str(resultado[i]['idcliente'])
                self.label_nome.text = resultado[i]['nome']
                self.label_telefone.text = str(resultado[i]['telefone'])
                self.label_nif.text = str(resultado[i]['nif'])
                self.label_email.text = resultado[i]['email']
                for widget in (self.botao_id, self.label_nome, self.label_telefone, self.label_nif, self.label_email):
                    self.ids.grid_informacao.add_widget(widget)
        else:

            self.ids.grid_informacao.clear_widgets()
            self.ids.grid_informacao.size_hint = (None, None)
            self.ids.grid_informacao.cols = 0
            self.ids.grid_informacao.padding = 20
            self.ids.grid_informacao.spacing = 5

    def mostra(self, instance):
        self.ids.grid_informacao.clear_widgets()
        self.ids.grid_informacao.cols = 4
        id_cliente = instance.text
        print('botao pressionado', instance)
        response = requests.get(self.uri + f'/{id_cliente}').json()  # uso o json para transformar em dicionario!
        resultado = response['cliente']
        if response['message'] == 'Everything went well!':
            print(type(resultado), resultado)
            self.ids.grid_informacao.size_hint = (1, 1)
            self.ids.grid_informacao.cols = len(resultado)

            for widget in (self.label_id1, self.label_nome1, self.label_telefone1, self.label_nif1, self.label_email1):
                self.ids.grid_informacao.add_widget(widget)

            self.botao_id = Button(text=str(resultado['idcliente']))
            label_nome = Label(text=resultado['nome'])
            label_telefone = Label(text=str(resultado['telefone']))
            label_nif = Label(text=str(resultado['nif']))
            label_email = Label(text=(resultado['email']))
            self.ids.grid_informacao.add_widget(self.botao_id)
            self.ids.grid_informacao.add_widget(label_nome)
            self.ids.grid_informacao.add_widget(label_telefone)
            self.ids.grid_informacao.add_widget(label_nif)
            self.ids.grid_informacao.add_widget(label_email)
        else:
            self.ids.grid_informacao.clear_widgets()
            self.ids.grid_informacao.cols = 1
            self.ids.grid_informacao.add_widget(self.erro)

    def ver_cliente_especifico(self):
        if self.ids.grid_informacao.cols == 0:
            self.input_informacao = Label(text='Insira o numero do cliente a pesquisar')
            self.id_input = TextInput(multiline=False, text="")
            self.erro = Label(text='Cliente não existe!')
            self.ids.grid_informacao.size_hint = (1, 0.15)
            self.ids.grid_informacao.cols = 2

            self.id_input.bind(on_text_validate=self.on_press_enter)

            self.ids.grid_informacao.add_widget(self.input_informacao)
            self.ids.grid_informacao.add_widget(self.id_input)
        else:
            self.ids.grid_informacao.clear_widgets()
            self.ids.grid_informacao.size_hint = (None, None)
            self.ids.grid_informacao.cols = 0

    def on_press_enter(self, instance):
        print('User pressed enter in', instance)
        id_cliente = instance.text

        response = requests.get(self.uri + f'/{id_cliente}').json()  # uso o json para transformar em dicionario!
        if response['message'] == 'Everything went well!':
            resultado = response['cliente']
            print(type(resultado), resultado)

            self.ids.grid_informacao.clear_widgets()

            self.ids.grid_informacao.size_hint = (1, 1)
            self.ids.grid_informacao.cols = len(resultado)

            for widget in (self.label_id1, self.label_nome1, self.label_telefone1, self.label_nif1, self.label_email1):
                self.ids.grid_informacao.add_widget(widget)

            self.botao_id = Button(text=str(resultado['idcliente']))
            label_nome = Label(text=resultado['nome'])
            label_telefone = Label(text=str(resultado['telefone']))
            label_nif = Label(text=str(resultado['nif']))
            label_email = Label(text=(resultado['email']))
            self.ids.grid_informacao.add_widget(self.botao_id)
            self.ids.grid_informacao.add_widget(label_nome)
            self.ids.grid_informacao.add_widget(label_telefone)
            self.ids.grid_informacao.add_widget(label_nif)
            self.ids.grid_informacao.add_widget(label_email)
        else:
            self.ids.grid_informacao.clear_widgets()
            self.ids.grid_informacao.cols = 1
            self.ids.grid_informacao.add_widget(self.erro)

    def inserir_novo_cliente(self):
        if self.ids.grid_informacao.cols == 0:
            self.ids.grid_informacao.cols = 2
            self.ids.grid_informacao.size_hint = (1, 1)
            self.label_nome = Label(text='Nome do cliente?')
            self.id_input_nome = TextInput(multiline=False, text="")
            self.label_telefone = Label(text='Telefone do cliente?')
            self.id_input_telefone = TextInput(multiline=False, text="")
            self.label_nif = Label(text='Nif do cliente?')
            self.id_input_nif = TextInput(multiline=False, text="")
            self.label_email = Label(text='email do cliente?')
            self.id_input_email = TextInput(multiline=False, text="")
            self.botao_criar = Button(text='Criar')

            for widget in (self.label_nome, self.id_input_nome, self.label_telefone, self.id_input_telefone, self.label_nif, self.id_input_nif, self.label_email, self.id_input_email):
                self.ids.grid_informacao.add_widget(widget)
            #self.add_widget(self.botao_criar)

        else:
            self.ids.grid_informacao.clear_widgets()
            self.ids.grid_informacao.size_hint = (None, None)
            self.ids.grid_informacao.cols = 0


    def atras(self):
        self.manager.current = 'paginainicial'
