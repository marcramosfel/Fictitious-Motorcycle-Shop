class user:
    user_connect = False
    is_master = False
    id_cliente = 0

user().user_connect = True

