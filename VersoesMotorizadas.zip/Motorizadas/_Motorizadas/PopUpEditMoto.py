from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from Motorizadas.utils import SavedWidgets, get_image_name, check_is_image
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.image import Image, AsyncImage
from kivy.uix.image import AsyncImage
from kivy.metrics import dp
from kivy.uix.filechooser import FileChooserIconView
from Motorizadas.Motorizadas_API import Motorizadas_API
import os
from Motorizadas.GLOBAL_VARIABLES import WEB_SERVICE_URI


######### DADO INFO MOTO ################
class MarcaCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 2
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Marca", font_size=dp(20))
        self.input = TextInput(multiline=False, font_size=dp(20))
        SavedWidgets.save("editMotoInputMarca", self.input)
        self.add_widget(self.label)
        self.add_widget(self.input)

class ModeloCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 2
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Modelo", font_size=dp(20))
        self.input = TextInput(multiline=False, font_size=dp(20))
        SavedWidgets.save("editMotoInputModelo", self.input)
        self.add_widget(self.label)
        self.add_widget(self.input)

class MatriculaCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 2
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Matricula", font_size=dp(20))
        self.input = TextInput(multiline=False, font_size=dp(20))
        SavedWidgets.save("editMotoInputMatricula", self.input)
        self.input.height = dp(10)
        self.add_widget(self.label)
        self.add_widget(self.input)

class dados_info_moto(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 3
        self.size_hint_y = 0.2
        self.add_widget(MarcaCampo())
        self.add_widget(ModeloCampo())
        self.add_widget(MatriculaCampo())


############ DADO INFO MOTO #######################


############ DADO SPECIFIC MOTO ##################

class CilindradaCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        #self.size_hint=(1,0.2)
        self.cols = 2
        #self.height = dp(20)
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Cilíndrada", font_size = dp(20))
        self.input = TextInput(multiline=False,font_size = dp(20), input_filter='float')
        SavedWidgets.save("editMotoInputCilindrada", self.input)
        self.input.height = dp(10)
        self.add_widget(self.label)
        self.add_widget(self.input)

class StockCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 2
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Stock", font_size=dp(20))
        self.input = TextInput(multiline=False, font_size=dp(20), input_filter='int')
        SavedWidgets.save("editMotoInputStock", self.input)
        self.input.height = dp(10)
        self.add_widget(self.label)
        self.add_widget(self.input)

class PrecoCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 2
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Preço", font_size=dp(20))
        self.input = TextInput(multiline=False, font_size=dp(20),input_filter='float')
        SavedWidgets.save("editMotoInputPreco", self.input)
        self.input.height = dp(10)
        self.add_widget(self.label)
        self.add_widget(self.input)



class dados_specific_moto(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 3
        self.size_hint_y = 0.2
        self.add_widget(CilindradaCampo())
        self.add_widget(StockCampo())
        self.add_widget(PrecoCampo())

############ DADO SPECIFIC MOTO ##################
############ ID MOTO ####################
class IdCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        SavedWidgets.save("editIdCampo",self)
        self.cols=2
        self.size_hint=(0.2,0.2)
        self.label = Label(text="Escolher Moto (ID)")
        self.label.font_size = dp(20)
        self.input = TextInput()
        self.input.font_size = dp(25)
        self.input.multiline = False
        self.input.input_filter = 'int'
        self.input.size_hint = (0.25,0.2)
        self.input.bind(text = self.getDataMoto)
        try:
            self.input.text = SavedWidgets.load("editIdCampoFirst")
        except:
            pass
        self.add_widget(self.label)
        self.add_widget(self.input)

    def getDataMoto(self, value,text):
        try:
            if len(text)<=0 or int(text)<=0:
                return
        except:
            return
        moto = Motorizadas_API.get_moto_by_id(text)
        if len(moto)==0:
            #value.text = str(moto[0])
            SavedWidgets.load("editMotoInputMarca").text = ""
            SavedWidgets.load("editMotoInputModelo").text = ""
            SavedWidgets.load("editMotoInputMatricula").text = ""
            SavedWidgets.load("editMotoInputCilindrada").text = ""
            SavedWidgets.load("editMotoInputStock").text = ""
            SavedWidgets.load("editMotoInputPreco").text = ""
            SavedWidgets.load("src_image_edit").text = WEB_SERVICE_URI + "static/images/default.png"
            SavedWidgets.load("name_image_edit").text = "default.png"
            SavedWidgets.load("preview_image_edit").source = WEB_SERVICE_URI + "static/images/default.png"
            return
        moto = moto[0]
        print(moto)
        #value.text = str(moto[0])
        SavedWidgets.load("editMotoInputMarca").text = str(moto[1])
        SavedWidgets.load("editMotoInputModelo").text = str(moto[2])
        SavedWidgets.load("editMotoInputMatricula").text = str(moto[3])
        SavedWidgets.load("editMotoInputCilindrada").text = str(moto[4])
        SavedWidgets.load("editMotoInputStock").text = str(moto[5])
        SavedWidgets.load("editMotoInputPreco").text = str(moto[6])
        SavedWidgets.load("src_image_edit").text = WEB_SERVICE_URI+"static/images/"+str(moto[7])
        SavedWidgets.load("name_image_edit").text = str(moto[7])
        SavedWidgets.load("preview_image_edit").source = WEB_SERVICE_URI+"static/images/"+str(moto[7])

class IdMoto(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 1
        self.size_hint = (None,None)
        self.size =(dp(400),dp(50))
        self.pos_hint = {'rigth': 0.01}
        self.add_widget(IdCampo())
############ ID MOTO ####################



########### INFO IMAGE ###########################

class table_info_image(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols= 2
        SavedWidgets.save("src_image_edit", Label(text="images/default.png"))
        SavedWidgets.save("name_image_edit", Label(text="default.png"))
        SavedWidgets.save("preview_image_edit", AsyncImage(source=WEB_SERVICE_URI + "static/images/default.png", size_hint=(0.7,0.7)))
        self.add_widget(Label(text="Src:"))
        self.add_widget(SavedWidgets.load("src_image_edit"))
        self.add_widget(Label(text="Nome:"))
        self.add_widget(SavedWidgets.load("name_image_edit"))

class info_image(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.add_widget(table_info_image())
        self.add_widget(SavedWidgets.load("preview_image_edit"))
########### INFO IMAGE ###########################
class Import(FileChooserIconView):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.bind(on_submit=self.teste)

    def teste(self, value,selection,touch):
        if isinstance(selection[0],str) and not check_is_image(selection[0]):
            Popup(title="Erro", separator_color=(1,0,0,0.8), size_hint=(0.4,0.4),content=Label(text="Tipo de ficheiro não suportado")).open()
            return False
        SavedWidgets.load("src_image_edit").text = selection[0]
        SavedWidgets.load("name_image_edit").text = get_image_name(selection[0])
        SavedWidgets.load("preview_image_edit").source = selection[0]
        SavedWidgets.load("popUpFiles_edit").dismiss()
class Button_Open_file_chooser(Button):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.text = "Upload de Imagem"
        self.size_hint = (0.25,None)
        self.height = dp(70)
        self.pos_hint = {'x':0.375}
        SavedWidgets.save("popUpFiles_edit", Popup(title="Escolher Imagem"))
        self.popup = SavedWidgets.load("popUpFiles_edit")
        self.popup.size_hint = (0.7,0.7)
        self.popup.content = Import()
        self.bind(on_press=self.popup.open)



class Form(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        SavedWidgets.save("formEditMoto", self)
        self.orientation = "vertical"
        self.padding = dp(30)
        self.spacing = dp(10)
        self.add_widget(dados_info_moto())
        self.add_widget(dados_specific_moto())
        self.add_widget(info_image())
        self.add_widget(Button_Open_file_chooser())
        self.add_widget(IdMoto())


class Btn(Button):
    def __init__(self,onClick,**kwargs):
        super().__init__(**kwargs)
        self.background_color = (0.9,0.3,0.1,1)
        self.bind(on_press=onClick)
        self.size_hint = (None,None)
        self.size= (dp(150),dp(50))

class btns_back_submit(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.btnSubmit = Btn(text="Editar", onClick=self.submit)
        self.btnSubmit.background_color=(0.074,0.568,0.039,1)
        self.size_hint = (None,None)
        self.height = self.btnSubmit.height
        self.add_widget(Btn(text="Voltar", onClick=popEditMoto.self.dismiss))
        self.add_widget(self.btnSubmit)

    def submit(instance, value):
        print("submit()")
        # Popup(title="Erro",separator_color=(1,0,0,1),content=Label("Erro"), size=(dp(300),dp(300))).open()
        inputs = {}
        inputs['id'] = SavedWidgets.load("editIdCampo").input.text
        inputs['marca'] = SavedWidgets.load("editMotoInputMarca").text
        inputs['modelo'] = SavedWidgets.load("editMotoInputModelo").text
        inputs['matricula'] = SavedWidgets.load("editMotoInputMatricula").text
        inputs['cilindrada'] = SavedWidgets.load("editMotoInputCilindrada").text
        inputs['stock'] = SavedWidgets.load("editMotoInputStock").text
        inputs['preco'] = SavedWidgets.load("editMotoInputPreco").text
        dados_por_preencher = []
        for i in inputs.keys():
            if len(inputs[i]) <= 0:
                dados_por_preencher.append(i)

        if len(dados_por_preencher) > 0:
            text_pop_erro = "Dados por preencher:\n"
            for i in dados_por_preencher:
                text_pop_erro += "    * " + i + "\n"
            Popup(title="Erro", separator_color=(1, 0, 0, 1), content=Label(text=text_pop_erro), size_hint=(None, None),
                  size=(dp(300), dp(200))).open()
            return

        if len(inputs['matricula']) > 11 or len(inputs['matricula']) <= 3:
            Popup(title="Erro", separator_color=(1, 0, 0, 1), content=Label(text="Matrícula inválida"),
                  size_hint=(None, None), size=(dp(300), dp(200))).open()
            return
        inputs['src_image'] = SavedWidgets.load("src_image_edit").text
        inputs['name_image'] = SavedWidgets.load("name_image_edit").text
        response = Motorizadas_API.edit_moto(inputs)
        if response['message'] == 'success':
            SavedWidgets.load("tableMotos").refresh()
            popEditMoto.self.dismiss()
            Popup(title="Sucesso!", separator_color=(0, 1, 0, 1), content=Label(text="Motorizada ID ("+inputs['id']+") editada com sucesso!"),
                  size_hint=(None, None),
                  size=(dp(300), dp(200))).open()
        else:
            Popup(title="Erro", separator_color=(1, 0, 0, 1), content=Label(text=response['message']),
                  size_hint=(None, None),
                  size=(dp(300), dp(200))).open()

class ContentEditMoto(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.orientation = "vertical"
        self.add_widget(Form())
        self.add_widget(btns_back_submit())

class popEditMoto(Popup):
    self = None
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        popEditMoto.self = self
        self.title = "Editar Moto"
        self.separator_color = (0.94,0.53,0,1)
        self.title_size = dp(20)
        self.content = ContentEditMoto()
        self.auto_dismiss = False
