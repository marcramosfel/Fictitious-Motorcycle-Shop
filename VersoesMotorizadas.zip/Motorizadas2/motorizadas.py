from GLOBAL_VARIABLES import *
import requests
import json

from utils import find_child_by_name

from kivy.uix.screenmanager import Screen
from kivy.uix.label import Label
from kivy.uix.stacklayout import StackLayout
from Motorizadas_API import Motorizadas_API
from kivy.uix.gridlayout import GridLayout
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import AsyncImage
from kivy.uix.textinput import TextInput
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.metrics import dp
from loginscreen import LoginScreen
from _Motorizadas.PopUpAddMoto import popAddMoto
from utils import SavedWidgets
from _Motorizadas.PopUpEditMoto import popEditMoto
from _Motorizadas.PopUpEditMoto import IdMoto
from _Motorizadas.PopUpComprarMoto import PopUpComprarMoto

class BarraNavegacao(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        if USER.is_master:
            self.add_widget(Btns_master())
        else:
            self.add_widget(Label(text="Catálogo", font_size= 50))

    def refresh_widget(self):
        child_widget = find_child_by_name(self, "barra_pesquisa")
        self.clear_widgets()
        print(USER.is_master)
        if USER.is_master:
            self.add_widget(child_widget)
            self.add_widget(Btns_master())
        else:
            self.add_widget(Label(text="Catálogo", font_size= 50))
            self.add_widget(child_widget)




class Btn(Button):
    def __init__(self,onClick,**kwargs):
        super().__init__(**kwargs)
        self.background_color = (0.9,0.3,0.1,1)
        self.bind(on_press=onClick)
        self.size_hint = (0.15,0.7)
        self.font_size = self.height - 80

class Btns_master(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.size_hint = (0.5,1)
        self.pos_hint={"x":0.25}
        self.add_widget(Btn(text="Adicionar Moto",onClick=self.add_moto))
        self.add_widget(Btn(text="Editar Moto", onClick=self.editar_moto))
    def add_moto(instance, value):
        if popAddMoto.self != None:
            popAddMoto.self.open()
        else:
            popAddMoto().open()

    def editar_moto(instance, value):
        print("editar()")

        if popEditMoto.self != None:
            popEditMoto.self.open()
        else:
            popEditMoto().open()

        # if PopUpEditSelect.self != None:
        #     PopUpEditSelect.self.open()
        # else:
        #     PopUpEditSelect().open()


class Search(TextInput):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bind(on_text_validate=self.search)

    def search_web_service(instance,text):
        response = requests.post(WEB_SERVICE_URI+"search_motos", json={"search":text})
        return json.loads(response.text)

    def search(instance,value):

        for i in instance.parent.parent.parent.children:
            try:
                if i.name == 'gridLayout_list':
                    for o in i.children:
                        try:
                            if o.name == 'scroll':
                                o.children[0].clear_widgets()

                                #Thead
                                fields = ['Id', "Marca", "Modelo", "Matricula", "Cilindrada", "Stock", "Preço"]
                                table = Row(0, cols=7, size_hint=(1, None), size=('200dp', '50dp'))
                                for i in fields:
                                    table.add_widget(Label(text=str(i)))
                                o.children[0].add_widget(table)

                                #Tbody

                                for p in Motorizadas_API.search_motos(value.text):
                                    row = Row(p[0],cols=7, size_hint = (1, None), size = ('200dp','50dp'))
                                    for q in p:
                                        row.add_widget(Label(text=str(q)))
                                    o.children[0].add_widget(row)
                        except:
                            pass
            except:
                pass


class ImageMoto(AsyncImage):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.size_hint = (1,1)
        self.source=WEB_SERVICE_URI+'static/images/default.png'
        self.name= "image_moto"


class Row(ButtonBehavior,GridLayout):
    def __init__(self, id,**kwargs):
        super().__init__(**kwargs)
        self.bind(on_press=self.select)
        self.id = id

    def select(instance, value):
        for i in instance.parent.children:
            for o in i.children:
                o.color = (1,1,1,1)
        if instance.children[-1].text != 'Id':
            try:
                SavedWidgets.load("editIdCampo").input.text = instance.children[-1].text
            except:
                print("passou")
                try:
                    SavedWidgets.save("editIdCampoFirst",instance.children[-1].text)
                except:
                    pass
            try:
                SavedWidgets.load("comprarMotoIdText").text = instance.children[-1].text
            except:
                try:
                    SavedWidgets.save("comprarMotoIdTextFirst", instance.children[-1])
                except:
                    pass
                pass
        for i in instance.children:
            i.color = (0.4,0.9,0.1,1)

        image_name = Motorizadas_API.get_name_moto_image(instance.id)
        find_child_by_name(instance.parent.parent.parent, "image_moto").source = WEB_SERVICE_URI+"static/images/"+image_name

class BoxImage(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.size_hint= (0.5, 1)
        self.orientation = 'vertical'
        self.add_widget(ImageMoto())
        self.btnComprar = Btn(text="Comprar", onClick=self.comprar)
        self.btnComprar.size_hint = (1,None)
        self.btnComprar.height = dp(50)
        self.add_widget(self.btnComprar)
    def comprar(instance, value):
        if USER.email == None:
            instance.pop = Popup(title="Iniciar sessão?", separator_color=(0.94,0.53,0,1))
            instance.pop.title_size = dp(20)
            instance.pop.size_hint = (0.65,0.4)
            box = BoxLayout(orientation="vertical")
            box.add_widget(Label(text="É necessário iniciar sessão para realizar uma compra.\n\nDeseja iniciar sessão?", font_size=dp(16)))
            box2 = BoxLayout(orientation = "horizontal")
            btnSim = Btn(text="Sim",onClick=instance.iniciar_sessao)
            btnSim.background_color = (0,1,0,1)
            box2.add_widget(btnSim)
            btnNao = Btn(text="Não",onClick=instance.pop.dismiss)
            btnNao.background_color = (1,0,0,1)
            box2.add_widget(btnNao)
            box.add_widget(box2)
            instance.pop.content = box
            instance.pop.open()
            return
        instance.formCompra(value)

    def iniciar_sessao(self,value):
        print("iniciar_sessao()")
        Motorizadas.self.manager.current = 'login'
        self.pop.dismiss()

    def formCompra(self,value):
        print("formCompra()")
        if PopUpComprarMoto.self ==None:
            PopUpComprarMoto().open()
        else:
            PopUpComprarMoto.self.open()


class StackLayoutTable(StackLayout):
    def refresh(self):
        self.clear_widgets()
        response = Motorizadas_API.lista_todas_motorizadas()
        fields = ['Id', "Marca", "Modelo", "Matricula", "Cilindrada", "Stock", "Preço"]
        table = Row(0, cols=7, size_hint=(1, None), size=('200dp', '50dp'))
        for i in fields:
            table.add_widget(Label(text=str(i)))
        self.add_widget(table)
        for num, i in enumerate(response):
            table = Row(i[0], cols=7, size_hint=(1, None), size=('200dp', '50dp'))
            for value in i:
                table.add_widget(Label(text=str(value)))
            self.add_widget(table)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        SavedWidgets.save('tableMotos', self)
        self.refresh()

class Motorizadas(Screen):
    self = None
    def __init__(self, teste = None,**kwargs):
        super().__init__(**kwargs)
        Motorizadas.self = self
        SavedWidgets.save('motorizadas',self)


    def search(self):
        search_widget = find_child_by_name(self,'search')
        search_widget.search(value=search_widget)

    def refresh(self):
        #apenas onde é preciso fazer um reload
        #refresh barraNavegacao
        barra_Navegacao = find_child_by_name(self, 'BarraNavegacao')
        barra_Navegacao.refresh_widget()
        #refresh tabela de motos
        SavedWidgets.load('tableMotos').refresh()

    def atras(self):
        if USER.email !=None:
            if USER.is_master == True:
                self.manager.current = 'paginainicialmaster'
            else:
                self.manager.current = 'paginainicialnormal'
        else:
            self.manager.current = 'login'

