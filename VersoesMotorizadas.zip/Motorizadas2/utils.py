import GLOBAL_VARIABLES
def find_child_by_name(object,name):
    try:
        for i in object.children:
            try:

                if i.name == name:

                    return i
                else:
                    if find_child_by_name(i,name) == None:
                        continue
                    else:
                        return find_child_by_name(i,name)
            except:

                if find_child_by_name(i,name) == None:
                    continue
                else:
                    return find_child_by_name(i,name)
    except:
        pass

class SavedWidgets:
    __arrSavedWidgets = {}
    @classmethod
    def save(cls,id,widget):
        print(cls)
        if id in cls.__arrSavedWidgets.keys():
            raise Exception("Error: already exists '"+id+"' id")
        cls.__arrSavedWidgets[id] = widget
        return True

    @classmethod
    def load(cls,id):
       return cls.__arrSavedWidgets[id]
    @classmethod
    def keys(cls):
        return cls.__arrSavedWidgets.keys()


def check_is_image(src):
    for i in range(len(src)):
        if src[-i] == '\\':
            name = src[-i:]
            for j in range(len(name)):
                if name[-j] == '.':
                    if name[-j+1:] in GLOBAL_VARIABLES.FORMATOS_DE_IMAGENS:
                        return True
            else:
                return False
    else:
        return False

def get_image_name(src):
    for i in range(len(src)):
        if src[-i] == '\\':
            name = src[-i:]
            for j in range(len(name)):
                if name[-j] == '.':
                    return name[1:-j]
            else:
                return name[1:]
    else:
        for j in range(len(src)):
            if src[-j] == '.':
                return src[:-j]
        else:
            return src


# def get_image_format(string):
#     for num,i in enumerate(string):
#         if string[-num] == '.':
#             return string[-num+1:]
#     else:
#         return False
