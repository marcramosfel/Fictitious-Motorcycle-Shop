from kivy.uix.screenmanager import Screen


class PaginaInicial(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def vai_para_clientes(self):
        self.manager.current = 'clientes'

    def vai_para_motorizadas(self):
        self.manager.current = 'motorizadas'

    def logout(self):
        self.manager.current = 'login'


