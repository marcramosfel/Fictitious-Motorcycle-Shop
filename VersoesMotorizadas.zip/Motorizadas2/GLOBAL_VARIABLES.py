class user:
    def __init__(self,email=None,is_master=False,id=None,name=None,password=None,phone=None):
        self.email = email
        self.is_master = is_master
        self.id = id
        self.name = name
        self.password = password
        self.phone = phone

    @property
    def id(self):
        return self.__id
    @id.setter
    def id(self,id):
        self.__id = id
        return self.__id

    @property
    def phone(self):
        return self.__phone

    @phone.setter
    def phone(self, phone):
        self.__phone = phone
        return self.__phone

    @property
    def password(self):
        return self.__password

    @password.setter
    def password(self, password):
        self.__password = password
        return self.__password

    @property
    def name(self):
        return self.__name
    @name.setter
    def name(self, name):
        self.__name = name
        return self.__name

    @property
    def email(self):
        return self.__email
    @email.setter
    def email(self,email):
        self.__email = email
        return self.__email

    @property
    def is_master(self):
        return self.__is_master

    @is_master.setter
    def is_master(self, is_master):
        self.__is_master = is_master
        return self.__is_master


#URI do web service
WEB_SERVICE_URI = 'http://127.0.0.1:5000/'


#Nome da base de dados
NOME_BASE_DADOS = "trabkivy"

#formatos de image para upload e preview
FORMATOS_DE_IMAGENS = ['jpg', 'png']

# USER ID
USER_ID = None

# USER EMAIL
USER_EMAIL = None

# USER NAME
USER_NAME = None

# USER PASSWORD
USER_PASSWORD = None

#USER PHONE
USER_PHONE = None

#USER IS MASTER 1 TRUE, 0 FALSE
USER_IS_MASTER = False

USER = user()
