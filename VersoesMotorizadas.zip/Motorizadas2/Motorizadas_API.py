import requests
import json
import GLOBAL_VARIABLES
class Motorizadas_API:
    uri = GLOBAL_VARIABLES.WEB_SERVICE_URI

    @classmethod
    def comprar_moto(cls,data):
        response = requests.post(cls.uri+"comprar_moto/",json=data)
        return json.loads(response.text)
    @classmethod
    def get_all_clientes(cls):
        response = requests.get(cls.uri+"cliente")
        return response.json()

    @classmethod
    def get_client_by_email(cls,email):
        if len(email) <=0:
            return {"message": "error"}
        response = requests.get(cls.uri+"cliente_by_email/"+email)
        return json.loads(response.text)

    @classmethod
    def lista_todas_motorizadas(cls):
        response = requests.get(cls.uri+"motorizadas")
        return response.json()

    @classmethod
    def get_moto_by_id(cls,id):
        response = requests.get(cls.uri+"motorizada/"+str(id))
        response = json.loads(response.text)
        if response["message"] == "success":

            return response["data"]
        return response

    @classmethod
    def get_name_moto_image(cls,id):
        response = requests.get(cls.uri + "get_moto_image/" + str(id))
        response = json.loads(response.text)
        if response["message"] == "success":
            image_name = response["data"]
        else:
            image_name = "default.png"

        return image_name


    @classmethod
    def search_motos(cls,text):
        response = requests.post(cls.uri + "search_motos", json={"search": text})
        return json.loads(response.text)

    @classmethod
    def add_moto(cls,data):
        #files = {'file':open(json['src_image'],'rb')}
        print(data)


        response = requests.post(cls.uri+ "addMoto/", json=data)
        print(response.status_code)
        response = json.loads(response.text)
        print(response)
        if response['message'] == 'success':
            response = requests.post(cls.uri + "add_image_moto/"+str(response['id']), files={'file': open(data['src_image'], 'rb')})
            return json.loads(response.text)
        else:
            return response

    @classmethod
    def edit_moto(cls,data):
        response = requests.post(cls.uri+"editMoto/",json=data)
        response = json.loads(response.text)
        print(data,response)
        if response["message"] == "success":
            try:
                response = requests.post(cls.uri+"edit_image_moto/"+str(response['id']),files={'file':open(data['src_image'],'rb')})
                return json.loads(response.text)
            except:
                return {"message":"success"}
        else:
            return response