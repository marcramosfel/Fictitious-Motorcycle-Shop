from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen
from utilizadores_masters import Utilizador
from kivy.uix.popup import Popup


class LoginScreen(Screen):
    def valida(self):
        dict_users_masters = Utilizador().utilizadores_masters()
        # print(users.utilizador, users.password, users.utilizadores_masters(), len(users.utilizadores_masters()))
        try:
            if dict_users_masters[self.ids.utilizador.text] == self.ids.password.text:
                print('ok')
                self.manager.current = "paginainicial"
            else:

                #     # self.ids.mensagem_erro.text = 'Password errada'
                text2 = "password errada"
                self.show_popup(text2)
                print('Falhou: password incorreta')

        except:
            self.show_popup("Falhou: utilizador não existe")
            print('Falhou: utilizador não existe')

    def registra(self):
        self.manager.current = 'registrar'

    def change_visible_password(self):
        if self.ids.password.password:
            self.ids.password.password = False
            self.ids.eye.background_normal = 'images/eye2.png'
        else:
            self.ids.password.password = True
            self.ids.eye.background_normal = 'images/eye.png'

    def show_popup(self, anchor):
        self.show = PopEmail(text=anchor)
        self.popupWindow = Popup(title="Erro", content=self.show, size_hint=(None, None),
                                  size=(400, 125), background_color=(0.9,0.3, 0.1, 1))
        self.popupWindow.open()

    def motorizadas(self):
        self.manager.current = "motorizadas"
class PopEmail(Label):
    pass
