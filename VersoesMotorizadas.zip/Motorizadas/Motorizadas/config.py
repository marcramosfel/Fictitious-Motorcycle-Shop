class DevelopmentConfig():
    DEBUG = True
    MYSQL_HOST = "localhost"
    MYSQL_USER = "root"
    MYSQL_PASSWORD = ""
    MySQL_DB = "trabkivy"


config = {
    'development': DevelopmentConfig
}
