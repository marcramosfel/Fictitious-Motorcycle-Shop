from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.popup import Popup
from kivy.uix.gridlayout import GridLayout
from kivy.metrics import dp
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.stacklayout import StackLayout
from kivy.uix.textinput import TextInput
from kivy.uix.filechooser import FileChooserIconView
from kivy.uix.image import Image
from Motorizadas.utils import SavedWidgets,get_image_name,check_is_image
from Motorizadas.GLOBAL_VARIABLES import WEB_SERVICE_URI
from Motorizadas.Motorizadas_API import Motorizadas_API
#from Motorizadas.motorizadas import StackLayoutTable
import os
###################################################
class MarcaCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 2
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Marca", font_size=dp(20))
        self.input = TextInput(multiline=False, font_size=dp(20))
        SavedWidgets.save("addMotoInputMarca", self.input)
        self.add_widget(self.label)
        self.add_widget(self.input)

class ModeloCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 2
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Modelo", font_size=dp(20))
        self.input = TextInput(multiline=False, font_size=dp(20))
        SavedWidgets.save("addMotoInputModelo", self.input)
        self.add_widget(self.label)
        self.add_widget(self.input)

class MatriculaCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 2
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Matricula", font_size=dp(20))
        self.input = TextInput(multiline=False, font_size=dp(20))
        SavedWidgets.save("addMotoInputMatricula", self.input)
        self.input.height = dp(10)
        self.add_widget(self.label)
        self.add_widget(self.input)

class dados_info_moto(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 3
        self.size_hint_y = 0.2
        self.add_widget(MarcaCampo())
        self.add_widget(ModeloCampo())
        self.add_widget(MatriculaCampo())



###################################################
class CilindradaCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        #self.size_hint=(1,0.2)
        self.cols = 2
        #self.height = dp(20)
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Cilíndrada", font_size = dp(20))
        self.input = TextInput(multiline=False,font_size = dp(20), input_filter='float')
        SavedWidgets.save("addMotoInputCilindrada", self.input)
        self.input.height = dp(10)
        self.add_widget(self.label)
        self.add_widget(self.input)

class StockCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 2
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Stock", font_size=dp(20))
        self.input = TextInput(multiline=False, font_size=dp(20), input_filter='int')
        SavedWidgets.save("addMotoInputStock", self.input)
        self.input.height = dp(10)
        self.add_widget(self.label)
        self.add_widget(self.input)

class PrecoCampo(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 2
        self.size_hint_min_y = dp(20)
        self.size_hint_max_y = dp(40)
        self.label = Label(text="Preço", font_size=dp(20))
        self.input = TextInput(multiline=False, font_size=dp(20),input_filter='float')
        SavedWidgets.save("addMotoInputPreco", self.input)
        self.input.height = dp(10)
        self.add_widget(self.label)
        self.add_widget(self.input)



class dados_specific_moto(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 3
        self.size_hint_y = 0.2
        self.add_widget(CilindradaCampo())
        self.add_widget(StockCampo())
        self.add_widget(PrecoCampo())

######################################################

class dados_photo_moto(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 1
        self.size_hint_y = 0.3
        self.add_widget(Button(text="text"))
class Form(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        SavedWidgets.save("formAddMoto", self)
        self.orientation = "vertical"
        self.add_widget(dados_info_moto())
        self.add_widget(dados_specific_moto())
        self.add_widget(info_image())
        self.add_widget(Button_Open_file_chooser())



class Btn(Button):
    def __init__(self,onClick,**kwargs):
        super().__init__(**kwargs)
        self.background_color = (0.9,0.3,0.1,1)
        self.bind(on_press=onClick)
        self.size_hint = (None,None)
        self.size= (dp(150),dp(50))


class Import(FileChooserIconView):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.bind(on_submit=self.teste)

    def teste(self, value,selection,touch):
        if isinstance(selection[0],str) and not check_is_image(selection[0]):
            Popup(title="Erro", separator_color=(1,0,0,0.8), size_hint=(0.4,0.4),content=Label(text="Tipo de ficheiro não suportado")).open()
            return False
        SavedWidgets.load("src_image").text = selection[0]
        SavedWidgets.load("name_image").text = get_image_name(selection[0])
        SavedWidgets.load("preview_image").source = selection[0]
        SavedWidgets.load("popUpFiles").dismiss()


class table_info_image(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols= 2
        SavedWidgets.save("src_image", Label(text="images/default.png"))
        SavedWidgets.save("name_image", Label(text="default.png"))
        SavedWidgets.save("preview_image", Image(source=os.getcwd() + "\\images\\default.png", size_hint=(0.7,0.7)))
        self.add_widget(Label(text="Src:"))
        self.add_widget(SavedWidgets.load("src_image"))
        self.add_widget(Label(text="Nome:"))
        self.add_widget(SavedWidgets.load("name_image"))

class info_image(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.add_widget(table_info_image())
        self.add_widget(SavedWidgets.load("preview_image"))

class Button_Open_file_chooser(Button):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.text = "Upload de Imagem"
        self.size_hint = (0.25,None)
        self.height = dp(70)
        self.pos_hint = {'x':0.375}
        SavedWidgets.save("popUpFiles", Popup(title="Escolher Imagem"))
        self.popup = SavedWidgets.load("popUpFiles")
        self.popup.size_hint = (0.7,0.7)
        self.popup.content = Import()
        self.bind(on_press=self.popup.open)

class btn_back_and_submit(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.orientation = "horizontal"
        self.btnToClosePopUp = Btn(text="Voltar", onClick=popAddMoto.self.dismiss)
        self.btnSubmit = Btn(text="Submeter", onClick=self.submit)
        self.btnSubmit.background_color = (0.074,0.568,0.039,1)
        self.size_hint = (None,None)
        self.height = self.btnSubmit.height
        self.add_widget(self.btnToClosePopUp)
        self.add_widget(self.btnSubmit)
    def submit(instance, value):
        print("submit()")
        #Popup(title="Erro",separator_color=(1,0,0,1),content=Label("Erro"), size=(dp(300),dp(300))).open()
        inputs={}
        inputs['marca'] = SavedWidgets.load("addMotoInputMarca").text
        inputs['modelo'] = SavedWidgets.load("addMotoInputModelo").text
        inputs['matricula'] = SavedWidgets.load("addMotoInputMatricula").text
        inputs['cilindrada'] = SavedWidgets.load("addMotoInputCilindrada").text
        inputs['stock'] = SavedWidgets.load("addMotoInputStock").text
        inputs['preco'] = SavedWidgets.load("addMotoInputPreco").text
        dados_por_preencher=[]
        for i in inputs.keys():
            if len(inputs[i]) <=0:
                dados_por_preencher.append(i)

        if len(dados_por_preencher)>0:
            text_pop_erro="Dados por preencher:\n"
            for i in dados_por_preencher:
                text_pop_erro += "    * "+i+"\n"
            Popup(title="Erro", separator_color=(1, 0, 0, 1), content=Label(text=text_pop_erro), size_hint=(None,None),size=(dp(300), dp(200))).open()
            return

        if len(inputs['matricula']) >11 or len(inputs['matricula'])<=3:
            Popup(title="Erro", separator_color=(1, 0, 0, 1), content=Label(text="Matrícula inválida"), size_hint=(None,None),size=(dp(300), dp(200))).open()
            return
        inputs['src_image']=SavedWidgets.load("src_image").text
        inputs['name_image']=SavedWidgets.load("name_image").text
        response = Motorizadas_API.add_moto(inputs)
        if response['message'] == 'success':
            SavedWidgets.load("tableMotos").refresh()
            popAddMoto.self.dismiss()
            Popup(title="Sucesso!", separator_color=(0, 1, 0, 1), content=Label(text="Motorizada adicionada com sucesso!"),
                  size_hint=(None, None),
                  size=(dp(300), dp(200))).open()
            SavedWidgets.load("addMotoInputMarca").text = ""
            SavedWidgets.load("addMotoInputModelo").text = ""
            SavedWidgets.load("addMotoInputMatricula").text = ""
            SavedWidgets.load("addMotoInputCilindrada").text = ""
            SavedWidgets.load("addMotoInputStock").text = ""
            SavedWidgets.load("addMotoInputPreco").text = ""
            SavedWidgets.load("src_image").text = "images/default.png"
            SavedWidgets.load("name_image").text = "default.png"
            SavedWidgets.load("preview_image").source = os.getcwd() + "\\images\\default.png"
        else:
            Popup(title="Erro", separator_color=(1, 0, 0, 1), content=Label(text=response['message']), size_hint=(None, None),
                  size=(dp(300), dp(200))).open()
class formAddMoto(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.orientation ='vertical'
        self.padding = dp(30)
        self.spacing = dp(10)
        self.add_widget(Form())
        self.add_widget(btn_back_and_submit())
class popAddMoto(Popup):
    self = None
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        popAddMoto.self = self
        self.title = "Adicionar Moto"
        self.separator_color = (0.94,0.53,0,1)
        self.title_size = dp(20)
        self.content = formAddMoto()
        self.auto_dismiss = False
