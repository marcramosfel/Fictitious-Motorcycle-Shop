from kivy.uix.screenmanager import ScreenManager
from kivy.app import App

from clientes import Cliente
from loginscreen import LoginScreen
from registrar import Registrar
from pagina_inicial import PaginaInicial
from motorizadas import Motorizadas


class MainApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(LoginScreen(name="login"))
        sm.add_widget(Cliente(name="clientes"))
        sm.add_widget(Registrar(name='registrar'))
        sm.add_widget(PaginaInicial(name='paginainicial'))
        sm.add_widget(Motorizadas(name="motorizadas"))
        return sm


MainApp().run()
