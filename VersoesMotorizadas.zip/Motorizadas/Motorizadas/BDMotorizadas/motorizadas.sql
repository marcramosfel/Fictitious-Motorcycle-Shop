-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 04-Dez-2021 às 18:24
-- Versão do servidor: 10.4.21-MariaDB
-- versão do PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `motorizadas`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `idcliente` int(11) NOT NULL,
  `nome` varchar(45) COLLATE utf8_bin NOT NULL DEFAULT 'Anonimo',
  `telefone` varchar(15) COLLATE utf8_bin DEFAULT 'Anonimo',
  `nif` int(9) NOT NULL,
  `email` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`idcliente`, `nome`, `telefone`, `nif`, `email`) VALUES
(1, 'Marcos Ramos', '918273641', 425367849, 'marcos@exemplo.com'),
(2, 'Alexandre Pita', '918127831', 182910281, 'alexandre@exemplo.com'),
(3, 'Cristiano Cabrita', '913110209', 901928312, 'cristiano@exemplo.com'),
(4, 'Rissa Veronica', '913232309', 918273121, 'raissa@exemplo.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `compra`
--

CREATE TABLE `compra` (
  `idcompra` int(11) NOT NULL,
  `data` datetime NOT NULL DEFAULT current_timestamp(),
  `quantidade` int(11) NOT NULL DEFAULT 1,
  `idcliente` int(11) NOT NULL,
  `idmotorizada` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `compra`
--

INSERT INTO `compra` (`idcompra`, `data`, `quantidade`, `idcliente`, `idmotorizada`) VALUES
(13, '2021-12-01 16:58:52', 10, 1, 17),
(14, '2021-12-01 16:58:52', 5, 1, 19),
(15, '2021-12-04 16:48:46', 10, 1, 17);

--
-- Acionadores `compra`
--
DELIMITER $$
CREATE TRIGGER `compra_AFTER_DELETE` AFTER DELETE ON `compra` FOR EACH ROW BEGIN
	UPDATE motorizada SET stock = stock + OLD.quantidade
    WHERE motorizada.idmotorizada = OLD.idmotorizada;

END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `compra_AFTER_INSERT` AFTER INSERT ON `compra` FOR EACH ROW BEGIN
	UPDATE motorizada SET  stock = stock - NEW.quantidade
    WHERE motorizada.idmotorizada = NEW.idmotorizada;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `compra_AFTER_UPDATE` AFTER UPDATE ON `compra` FOR EACH ROW BEGIN
	UPDATE motorizada SET  stock = stock - NEW.quantidade
    WHERE motorizada.idmotorizada = NEW.idmotorizada;
	UPDATE motorizada SET stock = stock + OLD.quantidade
    WHERE motorizada.idmotorizada = OLD.idmotorizada;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `motorizada`
--

CREATE TABLE `motorizada` (
  `idmotorizada` int(11) NOT NULL,
  `marca` varchar(45) COLLATE utf8_bin NOT NULL,
  `modelo` varchar(45) COLLATE utf8_bin NOT NULL,
  `matricula` varchar(45) COLLATE utf8_bin NOT NULL,
  `cilindrada` float(10,1) NOT NULL,
  `stock` int(11) UNSIGNED NOT NULL DEFAULT 0,
  `preco` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Extraindo dados da tabela `motorizada`
--

INSERT INTO `motorizada` (`idmotorizada`, `marca`, `modelo`, `matricula`, `cilindrada`, `stock`, `preco`) VALUES
(17, 'Honda', 'CB1000RA Black Edition', 'AA-00-11', 998.1, 100, '14800.00'),
(18, 'BMW ', 'R 1250 GS Edição', 'AA-00-12', 1254.0, 135, '20150.00'),
(19, 'Ducati ', 'XDiavel S', 'AA-00-13', 1262.0, 20, '23550.00');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`idcliente`),
  ADD UNIQUE KEY `nif_UNIQUE` (`nif`);

--
-- Índices para tabela `compra`
--
ALTER TABLE `compra`
  ADD PRIMARY KEY (`idcompra`),
  ADD KEY `fk_compra_clientes_idx` (`idcliente`),
  ADD KEY `fk_compra_motorizadas1_idx` (`idmotorizada`);

--
-- Índices para tabela `motorizada`
--
ALTER TABLE `motorizada`
  ADD PRIMARY KEY (`idmotorizada`),
  ADD UNIQUE KEY `matricula_UNIQUE` (`matricula`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `idcliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `compra`
--
ALTER TABLE `compra`
  MODIFY `idcompra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `motorizada`
--
ALTER TABLE `motorizada`
  MODIFY `idmotorizada` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `compra`
--
ALTER TABLE `compra`
  ADD CONSTRAINT `fk_compra_clientes` FOREIGN KEY (`idcliente`) REFERENCES `clientes` (`idcliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_compra_motorizadas1` FOREIGN KEY (`idmotorizada`) REFERENCES `motorizada` (`idmotorizada`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
