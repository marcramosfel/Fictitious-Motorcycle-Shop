from kivy.uix.screenmanager import Screen
from kivy.uix.label import Label
from kivy.uix.stacklayout import StackLayout
from Motorizadas_API import Motorizadas_API
from kivy.uix.gridlayout import GridLayout
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import AsyncImage
from kivy.uix.textinput import TextInput


class Search(TextInput):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.bind(focus=self.delete_placeHolder)
        self.bind(text=self.search)
    def search(instance,value, text):
        #print(instance.parent.parent.children[0].ids)
        for i in instance.parent.parent.children:
            try:
                if i.name == 'gridLayout_list':
                    for o in i.children:
                        try:
                            if o.name == 'scroll':
                                for p in o.children[0].children:
                                    print(p)
                                    #todas as rows
                                    for labels in p.children:
                                        if text in labels.text:
                                            print(text, labels.text)
                                        else:
                                            pass
                        except:
                            pass
            except:
                pass
                #print(i.id)
        print(instance.parent.parent.children,"ds")


    def delete_placeHolder(instance, value, value_focus):
        if value_focus == True:
            if value.text == 'pesquisar...':
                value.text = ""

class ImageMoto(AsyncImage):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.source='https://images.pexels.com/photos/674010/pexels-photo-674010.jpeg'


class Row(ButtonBehavior,GridLayout):
    def __init__(self, id,**kwargs):
        super().__init__(**kwargs)
        self.bind(on_press=self.print_teste)
        self.id = id

    def print_teste(instance, value):
        print(instance.id,instance.children, value)
        for i in instance.parent.children:
            for o in i.children:
                o.color = (1,1,1,1)
        for i in instance.children:
            i.color = (0.4,0.9,0.1,1)



class StackLayoutTable(StackLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        response = Motorizadas_API.lista_todas_motorizadas()
        print(response)
        for num,i in enumerate(response):
            table = Row(i[0],cols=7, size_hint = (1, None), size = ('200dp','50dp'))
            for value in i:
                table.add_widget(Label(text=str(value)))
            self.add_widget(table)

class Motorizadas(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def atras(self):
        self.manager.current = 'paginainicial'