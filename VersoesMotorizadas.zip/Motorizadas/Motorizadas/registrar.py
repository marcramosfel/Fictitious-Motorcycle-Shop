from kivy.uix.checkbox import CheckBox
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import Screen
from kivy.uix.textinput import TextInput

from utilizadores_masters import Utilizador

class GridLayoutTest(GridLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        check =  CheckBox()
        check.bind(active=self.on_checkbox_active)
        self.add_widget(check)

    def on_checkbox_active(self, checkbox, value):
        print(value)

class Registrar(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.codigo_master = '000'
        self.show = PopEmail()
        self.popupWindow = Popup(title="Erro", content=self.show, size_hint=(None, None),
                                 size=(400, 125), background_color=(0.9, 0.3, 0.1, 1))

    def on_checkbox_active(self, checkbox, value):
            print(value)

    def criar_utilizador(self):
        self.email = self.ids.criar_email.text
        self.password = self.ids.criar_password.text
        """if self.ids.check == False:
            print('falso')
            self.ids.registro_master.add_widget(Label(text= "Digite o código master"))
            self.ids.registro_master.add_widget(TextInput(password= True ))"""

        if self.ids.criar_password.text == self.ids.confirmar_password.text:
            if self.ids.codigomaster.text == self.codigo_master:
                print('Tudo Ok')
                label = Utilizador().coloca_utilizador(self.email, self.password)
                if label == 'O utilizador master foi criado!!':
                    self.show.text = 'Utilizador master criado'
                    self.show.color = (0, 0, 1, 1)
                    self.popupWindow.title = "Sucesso"
                    self.popupWindow.background_color = (0.1, 0.3, 0.9, 1)
                    self.show_popup()
                elif label == 'Ja existe um email associado!' or label == 'O email não é válido!!':
                    self.show.text = label
                    self.show.color = (1, 0, 0, 1)
                    self.popupWindow.title = "Erro"
                    self.popupWindow.background_color = (0.9, 0.3, 0.1, 1)
                    self.show_popup()
            else:
                self.show.text = 'Codigo Master Incorreto'
                self.show.color = (1, 0, 0, 1)
                self.popupWindow.title = "Erro"
                self.popupWindow.background_color = (0.9, 0.3, 0.1, 1)
                self.show_popup()
        else:
            self.show.text = 'Passwords Incompativeis'
            self.show.color = (1, 0, 0, 1)
            self.popupWindow.title = "Erro"
            self.popupWindow.background_color = (0.9, 0.3, 0.1, 1)
            self.show_popup()

    def atras(self):
        self.manager.current = 'login'

    def show_popup(self):

        self.popupWindow.open()


class PopEmail(Label):
    pass
