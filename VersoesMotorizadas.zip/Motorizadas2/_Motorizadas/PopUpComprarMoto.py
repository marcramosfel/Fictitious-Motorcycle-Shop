from Motorizadas_API import Motorizadas_API
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import AsyncImage
from kivy.uix.dropdown import DropDown
from kivy.metrics import dp
from GLOBAL_VARIABLES import USER_EMAIL,USER_IS_MASTER,USER, WEB_SERVICE_URI
from utils import SavedWidgets

from kivy.base import runTouchApp


class Btn(Button):
    def __init__(self,onClick,**kwargs):
        super().__init__(**kwargs)
        self.background_color = (0.9,0.3,0.1,1)
        self.font_size = dp(15)
        self.bind(on_press=onClick)
        self.size_hint = (None,None)
        self.size= (dp(200),dp(50))


class quantidade(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols=1
        self.size_hint = (0.3,1)
        self.clear_widgets()
        self.add_widget(Label(text="Quantidade:"))
        try:
            SavedWidgets.save("comprarMotoQuantidade", Label(text="1/..."))
            SavedWidgets.save("comprarMotoQuantidadeText",TextInput(multiline=False,text="1", input_filter='int',halign='center',font_size=dp(20),size_hint=(0.7,None), height=dp(50)))
        except:
            pass
        SavedWidgets.load("comprarMotoQuantidade").parent = []
        SavedWidgets.load("comprarMotoQuantidadeText").parent = []
        self.add_widget(SavedWidgets.load("comprarMotoQuantidade"))
        SavedWidgets.load("comprarMotoQuantidadeText").bind(text=self.multiply_preco)
        self.box = BoxLayout(orientation='horizontal', size_hint=(1,None), height=dp(50))
        self.btns = BoxLayout(orientation='vertical', size_hint=(None,None), size=(dp(50),dp(50)))
        self.btnUp = Button(background_color=(0.9,0.3,0.1,1),text="+1",halign='center')
        self.btnDown = Button(background_color=(0.9,0.3,0.1,1),text='-1',halign='center')
        self.btnUp.bind(on_press=self.add_1_quantidade)
        self.btnDown.bind(on_press=self.remove_1_quantidade)
        self.btns.add_widget(self.btnUp)
        self.btns.add_widget(self.btnDown)
        self.box.add_widget(SavedWidgets.load("comprarMotoQuantidadeText"))
        self.box.add_widget(self.btns)
        self.add_widget(self.box)

    def add_1_quantidade(self,value):
        SavedWidgets.load("comprarMotoQuantidadeText").text = str(int(SavedWidgets.load("comprarMotoQuantidadeText").text)+1)

    def remove_1_quantidade(self,value):
        if int(SavedWidgets.load("comprarMotoQuantidadeText").text)<=1:
            return
        SavedWidgets.load("comprarMotoQuantidadeText").text = str(int(SavedWidgets.load("comprarMotoQuantidadeText").text)-1)
    def multiply_preco(self,value,text):
        print("multiply_preco()")
        try:
            stock = SavedWidgets.load("comprarMotoQuantidade").text
            if int(text) > int(stock[2:]):
                value.text = stock[2:]
        except:
            value.text = str(1)
        try:
            if int(text) <=0:
                raise
        except:
            value.text = str(1)
        try:
            price = float(SavedWidgets.load("comprarPreco").text)
            if price <=0:
                return
            SavedWidgets.load("comprarMotoPreco").text = "Preço(€): " + str(price*int(value.text))
        except Exception as err:
            print(err.__repr__())
            pass
class info_moto(GridLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.cols = 1
        self.size_hint = (0.4,1)
        try:
            SavedWidgets.save("comprarMotoMarca",Label(text="Marca: ..."))
            SavedWidgets.save("comprarMotoModelo",Label(text="Modelo: ..."))
            SavedWidgets.save("comprarMotoCilindrada", Label(text="Cilindrada: ...") )
            SavedWidgets.save("comprarMotoPreco", Label(text="Preço(€): ..."))
            self.clear_widgets()
            self.children = []
            self.add_widget(SavedWidgets.load("comprarMotoMarca"))
            self.add_widget(SavedWidgets.load("comprarMotoModelo"))
            self.add_widget(SavedWidgets.load("comprarMotoCilindrada"))
            self.add_widget(SavedWidgets.load("comprarMotoPreco"))
        except:
            self.clear_widgets()
            self.children = []
            SavedWidgets.load("comprarMotoMarca").parent = []
            self.add_widget(SavedWidgets.load("comprarMotoMarca"))
            SavedWidgets.load("comprarMotoModelo").parent = []
            self.add_widget(SavedWidgets.load("comprarMotoModelo"))
            SavedWidgets.load("comprarMotoCilindrada").parent = []
            self.add_widget(SavedWidgets.load("comprarMotoCilindrada"))
            SavedWidgets.load("comprarMotoPreco").parent = []
            self.add_widget(SavedWidgets.load("comprarMotoPreco"))


class compraPropria(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        SavedWidgets.save("compraPropria", self)
        self.orientation = 'horizontal'
        self.size_hint = (1,0.8)
        SavedWidgets.save("comprarMotoImagem",AsyncImage(source='images/default.png', size_hint = (0.3,1)))
        self.add_widget(SavedWidgets.load("comprarMotoImagem"))
        self.add_widget(info_moto())
        self.add_widget(quantidade())


class SelectClient(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.inputText = TextInput(text="pesquisar...")
        self.inputText.bind(text=self.search)
        #self.add_widget(DropDownCliente())
        self.add_widget(self.inputText)
        self.info_about_email = Label(text="Email não encontrado!")

    def search(self,value,text):
        try:
            SavedWidgets.save("comprar_email_comprador",Label(text='None'))
        except:
            pass
        if text == 'pesquisar...' or len(text) <=0:
            if len(self.children) >1:
                del self.children[0]
        else:
            response = Motorizadas_API.get_client_by_email(text)
            if response['message'] == 'success':
                SavedWidgets.load("comprar_email_comprador").text = text
                if len(self.children) > 1:
                    self.children[0].text = 'Email encontrado!'
                else:
                    self.info_about_email.parent = []
                    self.info_about_email.text = 'Email encontrado!'
                    self.add_widget(self.info_about_email)
            else:
                SavedWidgets.load("comprar_email_comprador").text = 'None'
                if len(self.children) <2:
                    self.info_about_email.parent = []
                    self.info_about_email.text = 'Email não encontrado!'
                    self.add_widget(self.info_about_email)
                else:
                    self.children[0].text = 'Email não encontrado!'
        print(Motorizadas_API.get_client_by_email(text))

class master_SearchCliente(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        try:
            SavedWidgets.save("master_searchClient", self)
        except:
            pass
        self.orientation = 'horizontal'
        self.size_hint = (1,0.15)
        self.height = dp(300)
        self.spacing = dp(10)
        self.btn_compra_propria = Btn(text="Compra própria", onClick=self.click)
        self.btn_compra_propria.background_color = (0,1,0,1)
        self.btn_compra_propria.font_size=dp(20)
        self.btn_compra_cliente = Btn(text="Compra a cliente", onClick=self.click)
        self.selectClient = SelectClient()
        self.add_widget(self.btn_compra_propria)
        self.add_widget(self.btn_compra_cliente)
    def click(self,value):
        print("click()")
        try:
            SavedWidgets.save("masterClient",Label(text="cliente"))
        except:
            pass
        if "cliente" in value.text:
            SavedWidgets.load("masterClient").text = "cliente"
            self.btn_compra_propria.background_color = (0.9,0.3,0.1,1)
            self.btn_compra_propria.font_size = dp(15)
            value.background_color = (0,1,0,1)
            value.font_size = dp(20)
            self.clear_widgets()
            self.children = []
            self.add_widget(self.btn_compra_propria)
            self.add_widget(self.btn_compra_cliente)
            self.add_widget(self.selectClient)
        else:
            SavedWidgets.load("masterClient").text = "propria"
            self.btn_compra_cliente.background_color = (0.9,0.3,0.1,1)
            self.btn_compra_cliente.font_size = dp(15)
            value.background_color = (0,1,0,1)
            value.font_size = dp(20)
            self.clear_widgets()
            self.children = []
            self.add_widget(self.btn_compra_propria)
            self.add_widget(self.btn_compra_cliente)

class MostraCliente(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.size_hint = (1, 0.15)
        self.height = dp(300)
        self.spacing = dp(10)
        self.add_widget(Label(text='Utilizador '+USER.name+', '+USER.email))

class btns_back_submit(BoxLayout):
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.orientation = 'horizontal'
        self.size_hint = (1,0.1)
        self.spacing = dp(10)
        self.btn_back = Btn(text="Voltar", onClick=PopUpComprarMoto.self.dismiss)
        self.btn_comprar = Btn(text='Comprar', onClick=self.comprar)
        self.btn_comprar.background_color = (0,1,0,1)
        self.btn_comprar.font_size = dp(23)
        self.btn_comprar.bold = True
        self.add_widget(self.btn_back)
        self.add_widget(self.btn_comprar)
    def comprar(self,value):
        try:
            cliente = SavedWidgets.load("masterClient").text
        except:
            cliente = "propria"
        pop = Popup(title="Confirmar Compra", size_hint=(0.6,0.8))
        if len(SavedWidgets.load("comprarMotoIdText").text)<=0:
            return
        if cliente == "propria":
            print("propria")
            #popUop
            pop.content = fatura(pop)
            pop.open()
        else:
            print("cliente")
            try:
                self.comprador = SavedWidgets.load("comprar_email_comprador").text
            except:
                self.comprador = 'None'
            if self.comprador =='None':
                Popup(title='Email Inváido', size_hint=(0.4,0.5),content = Label(text="Email de comprador não é válido")).open()
                return
            pop.content = fatura(pop,comprador=self.comprador)
            pop.open()
        print("comprar()")

class fatura(GridLayout):
    def __init__(self,popUp,comprador=None,**kwargs):
        super().__init__(**kwargs)
        self.popUp =popUp
        self.cols = 2
        if comprador == None:
            self.comprador = USER.email
        else:
            self.comprador = comprador
        try:
            self.moto = SavedWidgets.load("comprarMotoMarca").text[6:]+",\n"+SavedWidgets.load("comprarMotoModelo").text[7:]
        except:
            self.moto=""
        try:
            self.unidades = SavedWidgets.load("comprarMotoQuantidadeText").text
        except:
            self.unidades = '1'
        try:
            self.preco_individual = SavedWidgets.load("comprarPreco").text + " €"
        except:
            self.preco_individual = ''
        try:
            self.preco_total = SavedWidgets.load("comprarMotoPreco").text[9:] + " €"
        except:
            self.preco_total = ''
        self.add_widget(Label(text='Comprador:'))
        self.add_widget(Label(text=self.comprador))

        self.add_widget(Label(text='Moto:'))
        self.add_widget(Label(text=self.moto))

        self.add_widget(Label(text='Unidades:'))
        self.add_widget(Label(text=self.unidades))

        self.add_widget(Label(text='Preço individual:'))
        self.add_widget(Label(text=self.preco_individual))

        self.add_widget(Label(text='Preço final:'))
        self.add_widget(Label(text=self.preco_total))
        self.add_widget(Btn(text='Cancelar', onClick=self.popUp.dismiss))
        self.btn_comprar=Btn(text='Finalizar Compra', onClick=self.finalizar_compra)
        self.btn_comprar.background_color=(0,1,0,1)
        self.add_widget(self.btn_comprar)
    def finalizar_compra(self,value):
        print("finalizar_compra")
        if len(SavedWidgets.load("comprarMotoIdText").text)<=0:
            return
        data={'MotoId':SavedWidgets.load("comprarMotoIdText").text, 'Comprador':self.comprador, 'Quantidade':self.unidades}
        response = Motorizadas_API.comprar_moto(data)
        if response["message"]=="success":
            self.popUp.dismiss()
            SavedWidgets.load("comprarMotoIdText").text = ""
            SavedWidgets.load("comprarMotoIdText").text = data['MotoId']
            Popup(title="Sucesso!", size_hint=(0.7, 0.5), content=Label(text="Comprar feita com sucesso!")).open()
        else:
            self.popUp.dismiss()
            Popup(title="Erro",size_hint=(0.7,0.5),content=Label(text=response["message"])).open()
class FormComprar(BoxLayout):
    self = None
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        FormComprar.self = self
        self.orientation= 'vertical'
        self.size_hint = (1,1)
        try:
            SavedWidgets.save("comprarMotoId", BoxLayout(orientation='horizontal', size_hint=(None, None),size=(dp(200),dp(50)), spacing=dp(10)))
            SavedWidgets.save("comprarMotoIdText",TextInput(font_size=dp(20),text="", input_filter='int',size_hint=(None,None), width=dp(50), height=dp(40),multiline=False))
        except:
            pass
        self.CampoId = SavedWidgets.load("comprarMotoId")
        if USER.is_master == True:
            self.add_widget(master_SearchCliente())
            self.add_widget(self.CampoId)
            self.add_widget(compraPropria())
            self.add_widget(btns_back_submit())
        else:
            self.add_widget(MostraCliente())
            self.add_widget(self.CampoId)
            self.add_widget(compraPropria())
            self.add_widget(btns_back_submit())


        SavedWidgets.load("comprarMotoIdText").bind(text=self.atualiza_info_moto)
        try:
            SavedWidgets.load("comprarMotoIdText").text = SavedWidgets.load("comprarMotoIdTextFirst").text
        except Exception as err:
            print(err.__repr__(),"ERRO")
            pass
        SavedWidgets.load("comprarMotoId").add_widget(Label(text="Id Moto", font_size=dp(20)))
        SavedWidgets.load("comprarMotoId").add_widget(SavedWidgets.load("comprarMotoIdText"))
    def atualiza_info_moto(self,value,text):
        print("atualiza_info_moto()")
        if len(text)<=0 or int(text) <=0:
            SavedWidgets.load("comprarMotoMarca").text = "Marca:..."
            SavedWidgets.load("comprarMotoModelo").text = "Modelo:..."
            SavedWidgets.load("comprarMotoCilindrada").text = "Cilindrada:..."
            SavedWidgets.load("comprarMotoPreco").text = "Preço:..."
            try:
                SavedWidgets.save("comprarPreco", Label(text='0.0'))
            except:
                SavedWidgets.load("comprarPreco").text = '0.0'

            SavedWidgets.load("comprarMotoQuantidade").text = "1/..."
            SavedWidgets.load("comprarMotoImagem").source = "images/default.png"
            return
        response = Motorizadas_API.get_moto_by_id(text)
        if len(response) > 0:
            SavedWidgets.load("comprarMotoMarca").text = "Marca: " + str(response[0][1])
            SavedWidgets.load("comprarMotoModelo").text = "Modelo: " + str(response[0][2])
            SavedWidgets.load("comprarMotoCilindrada").text = "Cilindrada: " + str(response[0][4])
            SavedWidgets.load("comprarMotoPreco").text = "Preço(€): " + str(response[0][6])
            try:
                SavedWidgets.save("comprarPreco",Label(text=str(response[0][6])))
            except:
                SavedWidgets.load("comprarPreco").text = str(response[0][6])
            SavedWidgets.load("comprarMotoQuantidade").text = "1/" + str(response[0][5])
            SavedWidgets.load("comprarMotoImagem").source = WEB_SERVICE_URI+'static/images/'+str(response[0][7])
            return
        else:
            SavedWidgets.load("comprarMotoMarca").text = "Marca:..."
            SavedWidgets.load("comprarMotoModelo").text = "Modelo:..."
            SavedWidgets.load("comprarMotoCilindrada").text = "Cilindrada:..."
            SavedWidgets.load("comprarMotoPreco").text = "Preço(€):..."
            try:
                SavedWidgets.save("comprarPreco",Label(text='0.0'))
            except:
                SavedWidgets.load("comprarPreco").text = '0.0'

            SavedWidgets.load("comprarMotoQuantidade").text = "1/..."
            SavedWidgets.load("comprarMotoImagem").source = "images/default.png"
            return
class PopUpComprarMoto(Popup):
    self = None
    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        PopUpComprarMoto.self = self
        self.title = "Comprar Moto"
        self.title_size = dp(25)
        self.separator_color = (0,1,0,1)
        self.content = FormComprar()

        self.bind(on_open=self.refresh_content)

    def refresh_content(self,value):
        if FormComprar.self == None:
            FormComprar()
        else:
            FormComprar.self.clear_widgets()
            if USER.is_master == True:
                FormComprar.self.add_widget(master_SearchCliente())
                FormComprar.self.add_widget(SavedWidgets.load("comprarMotoId"))
                FormComprar.self.add_widget(SavedWidgets.load("compraPropria"))
                FormComprar.self.add_widget(btns_back_submit())
            else:
                FormComprar.self.add_widget(MostraCliente())
                FormComprar.self.add_widget(SavedWidgets.load("comprarMotoId"))
                FormComprar.self.add_widget(SavedWidgets.load("compraPropria"))
                FormComprar.self.add_widget(btns_back_submit())
        #self.content = FormComprar()