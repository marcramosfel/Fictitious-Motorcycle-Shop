import json
import re


class Utilizador:
    def __init__(self):
        with open('utilizadores_masters.json') as json_file:
            dicionario_utilizadores = json.load(json_file)
        self.dicionario_utilizadores = dicionario_utilizadores

    def utilizadores_masters(self): #basicamente um getter
        return self.dicionario_utilizadores

    def coloca_utilizador(self, user, psw):
        valid = re.search(r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9]+\.[a-zA-Z\.a-zA-Z]{1,3}$', user)
        if self.dicionario_utilizadores.get(user):
            return 'Ja existe um email associado!'
        else:
            if valid:
                with open('utilizadores_masters.json', 'w') as json_file:
                    self.dicionario_utilizadores[user] = psw
                    json.dump(self.dicionario_utilizadores, json_file)
                return 'O utilizador master foi criado!!'
            else:
                return 'O email não é válido!!'
